Name: Noah Levitt
Fun Fact: I have Perfect Pitch! (a.k.a. Absolute Pitch)

All 6 of the regular exercises are working (by which I mean compiled, and exercise 0 returns the correct number of non-header rows).
The extra credit exercise has not been filled in, but nonetheless the program should compile correctly (it does on my end).

I am fairly sure that the 6 regular exercises return the correct results, although I haven't done any formal correctness tests.